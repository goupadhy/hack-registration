# sample-registrationPage-bootstrap
Contains sample user registration page bootstrap

## steps to access:
- Download the sample given above
- Run the index.html file using local path.

